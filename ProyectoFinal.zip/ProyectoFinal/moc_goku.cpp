/****************************************************************************
** Meta object code from reading C++ file 'goku.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../goku.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'goku.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN4GokuE_t {};
} // unnamed namespace


#ifdef QT_MOC_HAS_STRINGDATA
static constexpr auto qt_meta_stringdata_ZN4GokuE = QtMocHelpers::stringData(
    "Goku",
    "animar",
    "",
    "animarSalto",
    "actualizar",
    "volverASeleccion",
    "colisionPiedras",
    "colisionRocas",
    "animarPuno",
    "animarPatada",
    "reaccionGolpe",
    "desactivarTimers",
    "reanudarAnimacion",
    "setPausa",
    "estado",
    "spriteVictoria"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA

Q_CONSTINIT static const uint qt_meta_data_ZN4GokuE[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   92,    2, 0x0a,    1 /* Public */,
       3,    0,   93,    2, 0x0a,    2 /* Public */,
       4,    0,   94,    2, 0x0a,    3 /* Public */,
       5,    0,   95,    2, 0x0a,    4 /* Public */,
       6,    0,   96,    2, 0x0a,    5 /* Public */,
       7,    0,   97,    2, 0x0a,    6 /* Public */,
       8,    0,   98,    2, 0x0a,    7 /* Public */,
       9,    0,   99,    2, 0x0a,    8 /* Public */,
      10,    0,  100,    2, 0x0a,    9 /* Public */,
      11,    0,  101,    2, 0x0a,   10 /* Public */,
      12,    0,  102,    2, 0x0a,   11 /* Public */,
      13,    1,  103,    2, 0x0a,   12 /* Public */,
      15,    0,  106,    2, 0x0a,   14 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   14,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Goku::staticMetaObject = { {
    QMetaObject::SuperData::link<Personaje::staticMetaObject>(),
    qt_meta_stringdata_ZN4GokuE.offsetsAndSizes,
    qt_meta_data_ZN4GokuE,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_tag_ZN4GokuE_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Goku, std::true_type>,
        // method 'animar'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'animarSalto'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'actualizar'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'volverASeleccion'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'colisionPiedras'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'colisionRocas'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'animarPuno'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'animarPatada'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'reaccionGolpe'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'desactivarTimers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'reanudarAnimacion'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setPausa'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'spriteVictoria'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Goku::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<Goku *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->animar(); break;
        case 1: _t->animarSalto(); break;
        case 2: _t->actualizar(); break;
        case 3: _t->volverASeleccion(); break;
        case 4: _t->colisionPiedras(); break;
        case 5: _t->colisionRocas(); break;
        case 6: _t->animarPuno(); break;
        case 7: _t->animarPatada(); break;
        case 8: _t->reaccionGolpe(); break;
        case 9: _t->desactivarTimers(); break;
        case 10: _t->reanudarAnimacion(); break;
        case 11: _t->setPausa((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 12: _t->spriteVictoria(); break;
        default: ;
        }
    }
}

const QMetaObject *Goku::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Goku::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZN4GokuE.stringdata0))
        return static_cast<void*>(this);
    return Personaje::qt_metacast(_clname);
}

int Goku::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Personaje::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 13;
    }
    return _id;
}
QT_WARNING_POP
